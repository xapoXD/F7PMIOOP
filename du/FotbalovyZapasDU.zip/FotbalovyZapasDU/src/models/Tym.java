package models;

import java.util.Random;

public class Tym {

    public String nazev;

    public Tym(String nazev) {
        this.nazev = nazev;
    }


    public String getNazev() {
        return nazev;
    }


}
